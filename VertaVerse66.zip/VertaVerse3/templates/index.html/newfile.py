<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>VertaVerse - A Universe of Conversations</title>
<link rel="stylesheet" href="/static/style.css" />
</head>
<body>
  <header>
    <h1>VertaVerse</h1>
    <p>A Universe of Conversations</p>
  </header>
  
  {% for source, headlines in news.items() %}
  <section class="news-section">
    <h2>{{ source }}</h2>
    <ul>
      {% for headline in headlines %}
      <li>{{ headline }}</li>
      {% endfor %}
    </ul>
  </section>
  {% endfor %}
  
  <footer>
    <p>© 2025 VertaVerse. All rights reserved.</p>
  </footer>
</body>
</html>